import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import '../estilos/login.css';

const Login = () => {

  const [form, setForm] = useState({
    email: '',
    password: '',
  });

  const [isSignUp, setIsSignUp] = useState(false);
  const [loading, setLoading] = useState(false);
  const { signIn, signUp } = useAuth();
  const navigate = useNavigate();

  //////////////////////////////////////
  // Función para gestionar los cambios en los campos del formulario
  //////////////////////////////////////
  const gestionarCambio = (e) => {
    const { name, value } = e.target;

    setForm({
      ...form,
      [name]: value,
    });

  };

  //////////////////////////////////////
  // Función de validación
  //////////////////////////////////////
  const validar = () => {

    alert("Cuidado...no tengo validación")
    return true;

  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validar()) {
      return;
    }

    setLoading(true);

    try {
      let result;

      if (isSignUp) {
        result = await signUp(form.email, form.password);

        if (!result.error) {

          setIsSignUp(false);

          setForm({
            email: '',
            password: '',
          });

        }
      }

      else {
        result = await signIn(form.email, form.password);

        if (!result.error) {
          navigate('/');
        }
      }

      if (result.error) {
        setErrores({
          ...errores,
          submit: result.error.message,
        });
      }
    } catch (err) {

    } finally {

      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">

        <h2>{isSignUp ? 'Registrarse' : 'Iniciar Sesión'}</h2>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={form.email}
              onChange={gestionarCambio}
              required
              placeholder="tu@email.com"
            />

          </div>
          <div className="form-group">
            <label htmlFor="password">Contraseña</label>
            <input
              type="password"
              id="password"
              name="password"
              value={form.password}
              onChange={gestionarCambio}
              required
              placeholder="••••••••"

            />

          </div>

          <button
            type="submit"
            disabled={loading}
            className="login-button"
          >
            {loading ? 'Cargando...' : (isSignUp ? 'Registrarse' : 'Iniciar Sesión')}
          </button>
        </form>

        <div className="login-footer">
          <button
            type="button"
            onClick={() => {
              setIsSignUp(!isSignUp);
            }}
            className="toggle-button"
          >

            {isSignUp
              ? '¿Ya tienes cuenta? Inicia sesión'
              : '¿No tienes cuenta? Regístrate'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Login;