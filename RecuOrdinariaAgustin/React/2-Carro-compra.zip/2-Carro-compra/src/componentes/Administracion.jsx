import { useEffect, useState } from "react";
import servicioProductos from "../servicios/axios/servicioProductos";
//import Swal from "sweetalert2";
import ProductoConsultar from "./crud-productos/ProductoConsultar";
import ProductoBorrar from "./crud-productos/ProductoBorrar";
import Modal from "./Modal";
import '../estilos/Administracion.css';

const Administracion = () => {
  // Variables de Aficiones
  const [productos, setProductos] = useState([]);
  const [productoSeleccionado, setProductoSeleccionado] = useState({ "id": null, "url": null, "nombre": null, "precio": null });

  const [modals, setModals] = useState({
    consultar: false,

  });

  const gestionarModal = (tipoModal, estadoAbierto) => {
    //setModals((previoModals) => ({ ...previoModals, [tipoModal]: estadoAbierto }));

    setModals({
      ...modals,
      [tipoModal]: estadoAbierto,
    });


  };


  // ************************************************
  // Carga inicial de todas las aficiones, 
  // Gracias a UseEffect, se ejecuta una única vez
  // ************************************************
  useEffect(() => {
    servicioProductos.getAll()
      .then((response) => {
        setProductos(response.data);
      })
      .catch((error) => {

        Swal.fire({
          title: "¿Tienes Internet?",
          text: "No consigo descargar las aficiones :(",
          icon: "question"
        });
      });
  }, []);

  // ************************************************
  // Manejadores de Eventos de : editar , crear y borrar 
  // Gracias a UseEffect, se ejecuta una única vez
  // ************************************************
  const consultarProducto = (producto) => {


    setProductoSeleccionado(producto);
    gestionarModal("consultar", true)
  };


  const borrarProducto = (producto) => {

    ProductoBorrar(producto, productos, setProductos)
  }

  const EditarProducto = (producto) => {

    alert("Pendiente de implementar ....")
  }


  return (
    <>
      <ul className="aficiones-list">
        {productos.length > 0 ? (
          productos.map((producto) => (
            <li key={producto.id} className="aficion-item">
              <div>
                <strong>{producto.nombre}</strong>
                <strong>{producto.precio}</strong>
              </div>
              <div>
                <button onClick={() => consultarProducto(producto)}>Consulta</button>
                <button onClick={() => borrarProducto(producto)}>Borrar</button>
                <button onClick={() => EditarProducto(producto)}>Editar</button> 
              </div>
            </li>
          ))
        ) : (
          <p>No se encontraron productos.</p>
        )}
      </ul>

      <Modal isOpen={modals.consultar} onClose={() => gestionarModal("consultar", false)}>
        <ProductoConsultar producto={productoSeleccionado} />
      </Modal>

    </>
  );
};

export default Administracion;
